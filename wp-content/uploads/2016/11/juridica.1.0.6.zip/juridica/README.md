# juridica
