== Juridica ==

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License.
The exceptions to this license are as follows:

 * jquery.nicescroll
	
	Copyright 2011-13*InuYaksa
	Licensed under the MIT License, http://www.opensource.org/licenses/mit-license.php
 
 Screenshot image source: https://unsplash.imgix.net/photo-1426523038054-a260f3ef5bc9?q=75&fm=jpg&s=073c51b1bfe9f307e1f8c18e7da71aa1
 Screenshot image license: All unsplash.com images are licensed under the terms of the Creative Commons Zero, http://creativecommons.org/publicdomain/zero/1.0/