jQuery(document).ready(function() {
	jQuery("html").niceScroll();
	jQuery('header> .wide-header, header >.wrapper').wrapAll("<div class='wrap-elements'></div>");
});

